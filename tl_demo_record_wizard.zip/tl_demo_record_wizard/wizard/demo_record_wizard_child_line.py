"""Field/value configuration for the child records of a One2many field.

Owned by the template and keyed by the One2many field it configures, so that
several One2many relations can be configured side by side.
"""

from odoo import api, fields, models


class DemoRecordWizardChildLine(models.Model):
    _name = 'tl.demo.record.wizard.child.line'
    _inherit = ['tl.demo.value.mixin']
    _description = 'Demo Wizard Child Record Configuration'
    _order = 'parent_field_id, sequence, id'

    wizard_id = fields.Many2one(
        'tl.demo.record.wizard',
        string="Template",
        required=True,
        ondelete='cascade',
        index=True,
    )
    parent_field_id = fields.Many2one(
        'ir.model.fields',
        string="One2many Field",
        required=True,
        ondelete='cascade',
        help="The One2many field of the target model whose child records this "
             "line configures.")

    model_id = fields.Many2one(
        'ir.model', string="Child Model",
        compute='_compute_parent_context',
        help="Model the child records are created in.")
    inverse_name = fields.Char(
        compute='_compute_parent_context',
        help="Field pointing back at the parent record. Odoo fills it in, so "
             "it is never offered for configuration.")

    @api.depends('parent_field_id')
    def _compute_parent_context(self):
        IrModel = self.env['ir.model']
        for child in self:
            comodel = inverse = False
            parent_field = child.parent_field_id
            if parent_field and parent_field.relation:
                comodel = IrModel.sudo()._get(parent_field.relation)
                owner = self.env.get(parent_field.model)
                field = owner._fields.get(parent_field.name) if owner else None
                inverse = getattr(field, 'inverse_name', False) if field else False
            child.model_id = comodel.id if comodel else False
            child.inverse_name = inverse or False

    def _wizard(self):
        self.ensure_one()
        return self.wizard_id
