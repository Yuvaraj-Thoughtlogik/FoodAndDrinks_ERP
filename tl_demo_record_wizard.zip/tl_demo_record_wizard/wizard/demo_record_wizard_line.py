"""One field/value configuration line of a demo record template."""

from odoo import _, api, fields, models
from odoo.exceptions import UserError

from ..models import demo_field_utils as futils
from ..models.demo_value_mixin import SKIP


class DemoRecordWizardLine(models.Model):
    _name = 'tl.demo.record.wizard.line'
    _inherit = ['tl.demo.value.mixin']
    _description = 'Demo Wizard Field Configuration'
    _order = 'sequence, id'

    wizard_id = fields.Many2one(
        'tl.demo.record.wizard',
        string="Template",
        required=True,
        ondelete='cascade',
        index=True,
    )
    model_id = fields.Many2one(
        related='wizard_id.model_id', string="Model", readonly=True)

    def _wizard(self):
        self.ensure_one()
        return self.wizard_id

    # ------------------------------------------------------------------
    # One2many helpers
    # ------------------------------------------------------------------
    def _child_model(self):
        self.ensure_one()
        if not self.relation:
            return None
        return self.env.get(self.relation)

    def _child_inverse_name(self):
        """The child field pointing back at the parent - Odoo sets it itself."""
        self.ensure_one()
        if self.ttype != 'one2many':
            return False
        model = self.env.get(self.field_id.model)
        field = model._fields.get(self.field_id.name) if model else None
        return getattr(field, 'inverse_name', False) if field else False

    def _child_configuration(self):
        """The template's child lines that belong to this One2many field."""
        self.ensure_one()
        if self.ttype != 'one2many' or not self.wizard_id or not self.field_id:
            return self.env['tl.demo.record.wizard.child.line']
        return self.wizard_id.child_line_ids.filtered(
            lambda child: child.parent_field_id.id == self.field_id.id)

    def _child_line_vals(self, required_only=True):
        """``[(0, 0, vals)]`` commands for this One2many's child fields."""
        self.ensure_one()
        child_model = self._child_model()
        if child_model is None:
            return []
        inverse = self._child_inverse_name()
        candidates = (futils.required_fields(child_model) if required_only
                      else futils.configurable_fields(child_model))
        IrModelFields = self.env['ir.model.fields']
        commands = []
        for index, field in enumerate(candidates):
            if inverse and field.name == inverse:
                continue
            field_rec = IrModelFields._get(self.relation, field.name)
            if not field_rec:
                continue
            commands.append((0, 0, {
                'parent_field_id': self.field_id.id,
                'sequence': (index + 1) * 10,
                'field_id': field_rec.id,
                'use_random': field.type in futils.RANDOMISABLE_TTYPES,
                'value_count': 1,
            }))
        return commands

    # ------------------------------------------------------------------
    # validation
    # ------------------------------------------------------------------
    def _validate_one2many(self):
        self.ensure_one()
        label = self._label()
        child_model = self._child_model()
        if child_model is None:
            raise UserError(
                _("The child model of '%s' could not be resolved.", label))
        if self.value_count < 0:
            raise UserError(
                _("Number of Values on '%s' cannot be negative.", label))
        if not self.value_count:
            return

        children = self._child_configuration()
        if not children:
            raise UserError(
                _("'%(label)s' asks for %(count)s child record(s) but no child "
                  "field is configured. Fill in the '%(label)s' section, or "
                  "set Number of Values to zero.",
                  label=label, count=self.value_count))

        for child in children:
            if child.field_id.model != self.relation:
                raise UserError(
                    _("'%(child)s' belongs to %(other)s, not to %(model)s, so "
                      "it cannot be configured under '%(label)s'.",
                      child=child._label(), other=child.field_id.model,
                      model=self.relation, label=label))

        children._validate_for_creation()

        configured = set(children.mapped('field_name'))
        inverse = self._child_inverse_name()
        if inverse:
            configured.add(inverse)
        missing = [
            f for f in futils.required_fields(child_model)
            if f.name not in configured
        ]
        if missing:
            raise UserError(
                _("These required fields of %(model)s are not configured under "
                  "'%(label)s':\n%(fields)s",
                  model=self.relation, label=label,
                  fields='\n'.join(
                      '- %s (%s)' % (f.string, f.name) for f in missing)))

    # ------------------------------------------------------------------
    # value resolution
    # ------------------------------------------------------------------
    def _resolve_one2many(self, field):
        """One ``(0, 0, vals)`` command per child record to create."""
        self.ensure_one()
        children = self._child_configuration()
        count = self.value_count
        if count <= 0 or not children:
            return SKIP
        commands = []
        for _index in range(count):
            child_vals = {}
            for child in children:
                value = child._resolve_value()
                if value is SKIP:
                    continue
                child_vals[child.field_name] = value
            commands.append((0, 0, child_vals))
        return commands
