"""Demo record templates.

Pick a model, configure the fields you care about, say how many records you
want, press Create Records. Everything else is either taken from the model's
own defaults or generated at random, per record.

This is a **saved** record rather than a transient wizard, so a configuration
can be named, kept, duplicated and re-run. That also makes the editing work:
a transient wizard's x2many rows have no database id until it is saved, so
their row dialogs could not read back the fields they need and every value
input came up blank.

A template owns three tables: the fields of the target model, the child field
configuration of every One2many among them, and the records explicitly chosen
for every Many2many among them. All three hang off the template rather than
off each other, so each one is editable through its own row dialog instead of
being nested a level deeper than a sub-view can reach.
"""

import logging

from odoo import _, api, fields, models
from odoo.exceptions import UserError, ValidationError

from ..models import demo_field_utils as futils
from ..models.demo_value_mixin import SKIP

_logger = logging.getLogger(__name__)

MAX_RECORDS = 1000
MAX_CHILD_RECORDS = 10000


class DemoRecordWizard(models.Model):
    _name = 'tl.demo.record.wizard'
    _description = 'Demo Record Template'
    _order = 'name'

    name = fields.Char(
        string="Template Name",
        required=True,
        default=lambda self: self._default_name(),
        help="What this configuration is for, so it can be found and re-run.")
    active = fields.Boolean(default=True)

    last_run_date = fields.Datetime(
        string="Last Run", readonly=True, copy=False)
    last_created_count = fields.Integer(
        string="Records Created", readonly=True, copy=False,
        help="How many records the last run created.")

    model_id = fields.Many2one(
        'ir.model',
        string="Model",
        required=True,
        ondelete='cascade',
        domain=[('transient', '=', False)],
        help="The model records will be created in.")
    model_name = fields.Char(related='model_id.model', string="Technical Model")

    record_count = fields.Integer(
        string="Number of Records",
        default=1,
        required=True,
        help="How many records to create in the selected model.")

    line_ids = fields.One2many(
        'tl.demo.record.wizard.line', 'wizard_id', string="Fields")
    child_line_ids = fields.One2many(
        'tl.demo.record.wizard.child.line', 'wizard_id',
        string="Child Records Configuration")
    ref_ids = fields.One2many(
        'tl.demo.record.wizard.ref', 'wizard_id',
        string="Selected Records")

    line_count = fields.Integer(compute='_compute_summary')
    o2m_line_count = fields.Integer(compute='_compute_summary')
    m2m_line_count = fields.Integer(compute='_compute_summary')
    total_child_count = fields.Integer(compute='_compute_summary')

    allowed_field_ids = fields.Many2many(
        'ir.model.fields', compute='_compute_allowed_field_ids',
        string="Selectable Fields",
        help="Feeds the Field dropdown of the Fields table.")
    allowed_child_field_ids = fields.Many2many(
        'ir.model.fields', compute='_compute_relational_fields',
        string="Selectable Child Fields",
        help="Feeds the Child Field dropdown, narrowed further by the child "
             "model of the One2many each line belongs to.")

    o2m_field_ids = fields.Many2many(
        'ir.model.fields', compute='_compute_relational_fields',
        string="Configured One2many Fields",
        help="Feeds the domain of the child configuration table.")
    m2m_field_ids = fields.Many2many(
        'ir.model.fields', compute='_compute_relational_fields',
        string="Configured Many2many Fields",
        help="Feeds the domain of the selected records table.")

    apply_model_defaults = fields.Boolean(
        string="Apply Model Defaults",
        default=True,
        help="Let the model compute its own defaults and dependent values for "
             "every field you did not configure, the way the form view would.")
    open_records = fields.Boolean(
        string="Open Created Records",
        default=True,
        help="Show the created records in a list view once the wizard is done.")

    # ------------------------------------------------------------------
    # defaults
    # ------------------------------------------------------------------
    @api.model
    def _default_name(self):
        return _("New Demo Template")

    @api.onchange('model_id')
    def _onchange_model_id_name(self):
        """Name the template after its model until the user renames it."""
        for template in self:
            if template.model_id and template.name in (False, '', self._default_name()):
                template.name = _("%s demo", template.model_id.name)

    # ------------------------------------------------------------------
    # computes
    # ------------------------------------------------------------------
    @api.depends('line_ids.ttype', 'line_ids.value_count', 'record_count')
    def _compute_summary(self):
        for wizard in self:
            lines = wizard.line_ids
            o2m = lines.filtered(lambda line: line.ttype == 'one2many')
            wizard.line_count = len(lines)
            wizard.o2m_line_count = len(o2m)
            wizard.m2m_line_count = len(
                lines.filtered(lambda line: line.ttype == 'many2many'))
            wizard.total_child_count = (
                max(wizard.record_count, 0) * sum(o2m.mapped('value_count')))

    @api.depends('model_id')
    def _compute_allowed_field_ids(self):
        for wizard in self:
            wizard.allowed_field_ids = [(6, 0, futils.selectable_field_ids(
                self.env, wizard.model_id.model))]

    @api.depends('line_ids.ttype', 'line_ids.field_id')
    def _compute_relational_fields(self):
        for wizard in self:
            lines = wizard.line_ids
            o2m_lines = lines.filtered(lambda line: line.ttype == 'one2many')
            wizard.o2m_field_ids = o2m_lines.mapped('field_id')
            wizard.m2m_field_ids = lines.filtered(
                lambda line: line.ttype == 'many2many').mapped('field_id')

            child_ids = set()
            for line in o2m_lines:
                inverse = line._child_inverse_name()
                child_ids.update(futils.selectable_field_ids(
                    self.env, line.relation,
                    excluded=(inverse,) if inverse else (),
                    skip_types=('one2many',)))
            wizard.allowed_child_field_ids = [(6, 0, list(child_ids))]

    # ------------------------------------------------------------------
    # constraints
    # ------------------------------------------------------------------
    @api.constrains('record_count')
    def _check_record_count(self):
        for wizard in self:
            if wizard.record_count < 1:
                raise ValidationError(
                    _("Number of Records must be a positive integer."))
            if wizard.record_count > MAX_RECORDS:
                raise ValidationError(
                    _("Number of Records is capped at %s per run. Run the "
                      "wizard again for more.", MAX_RECORDS))

    # ------------------------------------------------------------------
    # onchange
    # ------------------------------------------------------------------
    @api.onchange('model_id')
    def _onchange_model_id(self):
        """Start from the model's required fields, as the spec asks."""
        for wizard in self:
            wizard.child_line_ids = [(5, 0, 0)]
            wizard.ref_ids = [(5, 0, 0)]
            wizard.line_ids = [(5, 0, 0)]
            if wizard.model_id:
                wizard.line_ids = wizard._line_vals(required_only=True)

    @api.onchange('line_ids')
    def _onchange_line_ids(self):
        """Keep the child and record tables in step with the field lines.

        Runs on every change to the lines, so picking a One2many immediately
        fills its child section with the child model's required fields, and
        removing a line takes its configuration with it.
        """
        for wizard in self:
            wizard._sync_relational_configuration()

    def _sync_relational_configuration(self):
        self.ensure_one()
        o2m_lines = self.line_ids.filtered(lambda l: l.ttype == 'one2many')
        o2m_field_ids = set(o2m_lines.mapped('field_id').ids)
        m2m_field_ids = set(
            self.line_ids.filtered(lambda l: l.ttype == 'many2many')
            .mapped('field_id').ids)

        stale = self.child_line_ids.filtered(
            lambda child: child.parent_field_id.id not in o2m_field_ids)
        if stale:
            self.child_line_ids = self.child_line_ids - stale

        stale_refs = self.ref_ids.filtered(
            lambda ref: ref.field_id.id not in m2m_field_ids)
        if stale_refs:
            self.ref_ids = self.ref_ids - stale_refs

        configured = set(self.child_line_ids.mapped('parent_field_id').ids)
        for line in o2m_lines:
            if line.field_id.id in configured:
                continue
            commands = line._child_line_vals(required_only=True)
            if commands:
                self.child_line_ids = commands

    # ------------------------------------------------------------------
    # buttons
    # ------------------------------------------------------------------
    def action_load_required_fields(self):
        self.ensure_one()
        self.child_line_ids = [(5, 0, 0)]
        self.ref_ids = [(5, 0, 0)]
        self.line_ids = [(5, 0, 0)] + self._line_vals(required_only=True)
        self._sync_relational_configuration()

    def action_load_all_fields(self):
        self.ensure_one()
        self.child_line_ids = [(5, 0, 0)]
        self.ref_ids = [(5, 0, 0)]
        self.line_ids = [(5, 0, 0)] + self._line_vals(required_only=False)
        self._sync_relational_configuration()

    def action_clear_fields(self):
        self.ensure_one()
        self.child_line_ids = [(5, 0, 0)]
        self.ref_ids = [(5, 0, 0)]
        self.line_ids = [(5, 0, 0)]

    def action_load_all_child_fields(self):
        """Replace every child section with all writable fields, not just the
        required ones."""
        self.ensure_one()
        self.child_line_ids = [(5, 0, 0)]
        commands = []
        for line in self.line_ids.filtered(lambda l: l.ttype == 'one2many'):
            commands += line._child_line_vals(required_only=False)
        if commands:
            self.child_line_ids = commands

    # ------------------------------------------------------------------
    # line building
    # ------------------------------------------------------------------
    def _target_model(self):
        self.ensure_one()
        if not self.model_id:
            raise UserError(_("Select a model first."))
        model = self.env.get(self.model_id.model)
        if model is None:
            raise UserError(
                _("Model '%s' does not exist in this database.",
                  self.model_id.model))
        if model._transient:
            raise UserError(
                _("'%s' is a transient model, its records would be deleted "
                  "again shortly. Pick another model.", self.model_id.model))
        return model

    def _line_vals(self, required_only=True):
        self.ensure_one()
        model = self._target_model()
        candidates = (futils.required_fields(model) if required_only
                      else futils.configurable_fields(model))
        IrModelFields = self.env['ir.model.fields']
        commands = []
        for index, field in enumerate(candidates):
            field_rec = IrModelFields._get(model._name, field.name)
            if not field_rec:
                continue
            commands.append((0, 0, {
                'sequence': (index + 1) * 10,
                'field_id': field_rec.id,
                'use_random': field.type in futils.RANDOMISABLE_TTYPES,
                'value_count': 1,
            }))
        return commands

    # ------------------------------------------------------------------
    # validation
    # ------------------------------------------------------------------
    def _validate(self):
        self.ensure_one()
        model = self._target_model()

        if self.record_count < 1:
            raise UserError(_("Number of Records must be a positive integer."))
        if self.record_count > MAX_RECORDS:
            raise UserError(
                _("Number of Records is capped at %s per run.", MAX_RECORDS))
        if self.total_child_count > MAX_CHILD_RECORDS:
            raise UserError(
                _("This configuration would create %(total)s child records, "
                  "over the %(cap)s limit. Lower Number of Records or Number "
                  "of Values.",
                  total=self.total_child_count, cap=MAX_CHILD_RECORDS))

        self._check_create_access(model)

        # one line per field, otherwise the last one silently wins
        seen = {}
        for line in self.line_ids:
            if not line.field_id:
                raise UserError(
                    _("One configuration line has no field selected."))
            if line.field_id.model != model._name:
                raise UserError(
                    _("'%(field)s' belongs to %(other)s, not to %(model)s.",
                      field=line._label(), other=line.field_id.model,
                      model=model._name))
            if line.field_name in seen:
                raise UserError(
                    _("'%s' is configured twice. Remove one of the lines.",
                      line._label()))
            seen[line.field_name] = line

        for ref in self.ref_ids:
            if not ref.field_id or ref.field_id.id not in self.m2m_field_ids.ids:
                raise UserError(
                    _("A selected record refers to '%s', which is not a "
                      "Many2many field configured above.",
                      ref.field_id.field_description or _("(no field)")))

        self.line_ids._validate_for_creation()

        missing = [
            f for f in futils.required_fields(model) if f.name not in seen
        ]
        if missing:
            raise UserError(
                _("These required fields of %(model)s are not configured:\n"
                  "%(fields)s\n\nUse 'Load Required Fields' to add them.",
                  model=model._name,
                  fields='\n'.join(
                      '- %s (%s)' % (f.string, f.name) for f in missing)))

    def _check_create_access(self, model):
        self.ensure_one()
        try:
            if hasattr(model, 'check_access'):
                model.check_access('create')
            else:  # Odoo <= 17
                model.check_access_rights('create')
        except UserError:
            raise
        except Exception as exc:
            raise UserError(
                _("You are not allowed to create %(model)s records.\n\n%(err)s",
                  model=model._name, err=exc)) from exc

    # ------------------------------------------------------------------
    # creation
    # ------------------------------------------------------------------
    def action_create_records(self):
        self.ensure_one()
        self._validate()
        model = self._target_model()

        vals_list = [self._build_vals(model, index)
                     for index in range(self.record_count)]

        try:
            with self.env.cr.savepoint():
                records = model.create(vals_list)
                # surface SQL constraints and model constraints now, while we
                # are still inside the savepoint
                if hasattr(records, 'flush_recordset'):
                    records.flush_recordset()
                elif hasattr(self.env, 'flush_all'):
                    self.env.flush_all()
        except (UserError, ValidationError):
            raise
        except Exception as exc:
            _logger.warning(
                "Demo Record Creation Wizard failed on %s", model._name,
                exc_info=True)
            raise UserError(
                _("%(model)s refused the generated values:\n\n%(err)s\n\n"
                  "Nothing was created. Adjust the configuration and try "
                  "again.", model=model._name, err=exc)) from exc

        self.write({
            'last_run_date': fields.Datetime.now(),
            'last_created_count': len(records),
        })
        return self._result_action(model, records)

    def _build_vals(self, model, index):
        """Values for one generated record."""
        self.ensure_one()
        vals = {}
        for line in self.line_ids:
            value = line._resolve_value()
            if value is SKIP:
                continue
            vals[line.field_name] = value
        return self._merge_model_defaults(model, vals)

    def _merge_model_defaults(self, model, vals):
        """Let the model fill in what the user did not configure.

        Reads every writable stored field off an in-memory record, which runs
        the model's defaults and its computed-editable fields - the modern
        equivalent of the values a form view's onchanges would have produced.
        Explicitly configured values always win.
        """
        self.ensure_one()
        if not self.apply_model_defaults:
            return vals
        try:
            record = model.new(dict(vals))
        except Exception:
            _logger.debug("Could not build an in-memory %s", model._name,
                          exc_info=True)
            return vals

        extra = {}
        for name, field in model._fields.items():
            if name in vals or name in futils.MAGIC_FIELDS:
                continue
            if field.readonly or field.related or not field.store:
                continue
            if field.compute and not field.inverse:
                continue
            if field.type in ('one2many', 'many2many', 'binary',
                              'json', 'properties', 'properties_definition'):
                continue
            try:
                value = record[name]
            except Exception:
                continue
            if not value:
                continue
            extra[name] = value.id if field.type == 'many2one' else value

        extra.update(vals)
        return extra

    def _result_action(self, model, records):
        self.ensure_one()
        if not self.open_records:
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'type': 'success',
                    'title': _("Records created"),
                    'message': _("%(count)s %(model)s record(s) created.",
                                 count=len(records), model=self.model_id.name),
                },
            }
        return {
            'type': 'ir.actions.act_window',
            'name': _("Created %s Records", self.model_id.name),
            'res_model': model._name,
            'view_mode': 'list,form',
            'domain': [('id', 'in', records.ids)],
            'target': 'current',
        }
