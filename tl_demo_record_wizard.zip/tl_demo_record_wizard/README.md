# Demo Record Templates

Generate demo records for **any** model in the database, with a value input
that adapts to each field's technical type.

Templates are **saved records**, not a throwaway wizard: name a configuration,
keep it, duplicate it, re-run it whenever you need more demo data.

*Odoo 19 · Thoughtlogik Technology Solutions · LGPL-3*

---

## Where to find it

**Settings → Technical → Demo Record Templates** (System Administrator only).

## How it works

1. **Pick a model.** The template immediately loads every *required, writable*
   field of that model as a configuration line, so the shortest possible run is
   "choose model, choose count, Create Records".
2. **Click a line to configure it.** Each line is one field, and its dialog
   shows exactly the input that field's type calls for, full width - a date
   picker for a Date, a dropdown of the field's own options for a Selection, a
   searchable record selector for a Many2one, a checkbox for a Boolean. Every
   other input stays hidden, so there is one thing to fill in and no guessing
   which column belongs to which type.
3. **Set the number of records** and press *Create Records*. The created
   records open in a list view, and the template notes when it ran and how
   many it produced.
4. **Re-run or duplicate** it later. Duplicating copies every line, so one
   template can seed several variations.

### The Value cell and Random

**A value you enter always wins.** Set the value in the dialog and that value
is used; Random switches itself off as you type. Random only applies while the
value is empty, and then it generates a *fresh* value for every record in the
batch - a hundred records are a hundred different records, not a hundred
copies.

Integer, Decimal and Checkbox are the exception: `0` and an unticked box are
indistinguishable from "nothing entered", so for those three untick Random to
use the number or the tick you entered.

The tables themselves are read-only summaries - field, type, whether it is
random, and the value in words. All editing is in the dialogs, which is also
why the tables stay narrow enough to read.

### Three tables, all on the template

A Many2many's chosen records and a One2many's child fields do not fit in a
single cell, so each gets a tab of its own:

| Tab | Shows | Appears when |
| --- | --- | --- |
| Fields to Populate | one line per field of the target model | a model is selected |
| Child Records | the child fields of every One2many line | a One2many line exists |
| Selected Records | the records picked for every Many2many line | a Many2many line exists |

Both extra tables hang off the **template**, not off the line, and are keyed
by the `ir.model.fields` record they belong to, so all three sit at the same
level and each is editable through its own row dialog rather than being nested
a level deeper than a sub-view can reach.

Pick a One2many and its child table fills itself with the child model's
required fields immediately - an onchange on the template, not on the line,
so the values survive.

### Why a dialog rather than an editable table

A line carries one column per input shape - text, number, decimal, date,
datetime, option, record, file - because each type needs its own widget. Put
all of them in one editable table and it is thirteen columns wide with twelve
of them blank on any given row. The row dialog shows one input at a time
instead.

**Visibility is driven by `ttype`, never by a computed field.** That is not a
style preference. A computed field is only present in a record the client has
actually read *with that field in its spec*; a value group hidden behind a
`value_widget` the client never fetched renders completely empty. `ttype` is a
related field on `ir.model.fields` and is in every table's field list, so it
is always there.

The same class of problem is why this is a saved model rather than a transient
wizard. A transient record's x2many rows have no database id until it is
saved, so their dialogs cannot read back anything the parent list did not
already carry, and `type="object"` row buttons fail outright with *"Please
save your changes first"*.

One thing still needs `parent.`: a row created in a dialog has no link back to
the template yet, so it cannot compute anything from it. The Field dropdowns
are fed by lists computed on the **template** — `allowed_field_ids` for the
target model's fields, `allowed_child_field_ids` for the child models',
`o2m_field_ids` and `m2m_field_ids` for the relational lines configured.

## Input per field type

| Field type | Input shown | Random value when left blank |
| --- | --- | --- |
| Char | text input, clipped to the column size | name-aware string (email, phone, url, postcode, code, city, street) |
| Text | multiline text | a few generated sentences |
| Html | multiline text | the same, wrapped in `<p>` |
| Integer | integer input | 1 - 999 |
| Float / Monetary | decimal input, field's own precision | 1.00 - 999.00 |
| Boolean | checkbox | true or false |
| Date | date picker | today ± 180 days |
| Datetime | datetime picker | today ± 180 days, on a quarter hour |
| Selection | dropdown of the field's own options | one of those options |
| Many2one | model + record selector, searchable | a random existing record |
| Many2many | list of searchable record selectors | *Number of Values* random records |
| One2many | nested field/value configuration | *Number of Values* child records per parent |
| Binary | file upload | a small generated text payload |
| Reference | model selector, then record search | a random record of an allowed model |

Every one of those inputs lives in the line's dialog. Many2many and One2many
additionally have a tab of their own, because a list of chosen records and a
set of child fields are more than one input each.

## One2many configuration

Select a One2many field and the *Child Records* tab fills itself with the
required fields of the child model, excluding the inverse field (Odoo fills
that in itself). *Number of Values* on the parent line decides how many child
records each parent gets, and every child record re-rolls its random values
independently.

So for a Sale Order you configure Sale Order fields in the first tab and
Sale Order Line fields in the second, with *Of Field* saying which One2many
each child line belongs to - so several One2many relations can be configured
side by side. One level of nesting is supported, which is what the requirement
asks for.

## Which fields are offered

A field is configurable when `create()` will actually accept a value for it.
Excluded:

- Odoo's own bookkeeping fields (`id`, `create_uid`, `write_date`, ...)
- read-only fields, including stored computed fields left read-only
  (`price_subtotal`)
- related fields
- computed fields that are neither stored nor equipped with an inverse, so a
  written value would have nowhere to go (`sale.order.line.product_template_id`)
- fields with no column of their own to land in
- One2many fields with no inverse field
- unsupported types (`json`, `properties`, `many2one_reference`, ...)
- for a child model, the One2many's inverse field, and a second level of
  One2many

Stored computed fields left *editable* — `readonly=False`, the modern
replacement for an onchange — **are** offered, because they take a written
value perfectly well. `sale.order.line.product_uom_qty` and `name` are both of
this shape, so quantities and descriptions can be configured.

The Field dropdown is fed by this same rule, computed in Python into
`allowed_field_ids`, rather than by a domain on `ir.model.fields`. That table
cannot express the rule: its `compute` column only holds code for *custom*
fields, so a domain has no way to tell a Python computed field from a plain
one. Feeding the dropdown from the function that validates the choice is what
stops the two from disagreeing — and a disagreement is exactly what produced
*"'Product Template' cannot be used by this wizard"* on a field the dropdown
had happily offered.

## Validation

Nothing is written until the whole configuration passes:

- create access on the target model (`check_access`)
- every required field of the model has a value or a random generator
- no field configured twice
- Selection values checked against the field's real options
- Many2one / Many2many / Reference values checked against the target model,
  and the records checked for existence
- enough related records actually exist to satisfy a random request - asking
  for 10 random partners when 3 exist is reported before anything is created
- positive record counts, with a cap of 1 000 records and 10 000 child records
  per run

Creation runs in a single savepoint. If the model rejects a value, its own
error message is shown and **nothing** is created - no half-finished batch to
clean up.

## Model defaults

*Apply Model Defaults* (on by default) builds an in-memory record from the
configured values and reads back the model's own defaults and
computed-editable fields before writing - the modern equivalent of the values
a form view's onchanges would have produced. Explicit values always win over
anything the model suggests.

## Layout

```
models/
  demo_field_utils.py   which fields are usable, type -> input mapping
  demo_random.py        one random generator per technical type
  demo_value_mixin.py   the typed value columns, validation and resolution
wizard/
  demo_record_wizard.py             the template: model, count, validation, run
  demo_record_wizard_line.py        one configured field of the target model
  demo_record_wizard_child_line.py  one configured field of a One2many child
  demo_record_wizard_ref.py         one explicitly chosen related record
```

The models are persistent (`models.Model`) despite living in `wizard/` and
being named `tl.demo.record.wizard*`. The folder and the technical names are
kept from when this was a transient wizard, deliberately: renaming four
models means renaming every ACL row, view and XML id, and the names are not
what the user sees.

The value half of a line lives in the `tl.demo.value.mixin` abstract model, so
the parent lines and the One2many child lines share exactly the same typed
columns, widgets, validation and random generation - the child configuration
behaves identically to the parent one by construction rather than by
duplication.
